/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.phan2;

import com.formdev.flatlaf.FlatLightLaf;
import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author balis
 */
public class bai2 extends javax.swing.JFrame {

    boolean addNew = false;
    boolean fill = false;
    Vector data = new Vector();
    Vector header = new Vector();
    Vector col = new Vector();
    Connection conn = null;
    PreparedStatement pstDetails = null;
    PreparedStatement pstInsert = null;
    PreparedStatement pstDelete = null;
    PreparedStatement pstUpdate = null;
    String sqlInsert = "insert into students([name], [address], [parentname], [phone], [standard]) values (?,?,?,?,?)";
    String sqlDelete = "delete from students where name = ?";
    String sqlUpdate = "update students set address = ?, parentname = ?,phone = ?, standard = ? where name = ?";
    ResultSet rs;

    String username = "sa";
    String password = "1221";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=LAB6_SCHOOL;";

    /**
     * Creates new form bai2
     */
    public bai2() {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        try {
            conn = DriverManager.getConnection(url, username, password);
            pstInsert = conn.prepareStatement(this.sqlInsert);
            pstDelete = conn.prepareStatement(this.sqlDelete);
            pstUpdate = conn.prepareStatement(this.sqlUpdate);
            pstDetails = conn.prepareStatement("select * from students", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = pstDetails.executeQuery();
            JOptionPane.showMessageDialog(parentField, "Succesfully connect to database!");
            loadComboBox();
            loadData();
            fill = true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, e);
        }
    }

    private void loadComboBox() {
        String SQL = "select * from standards";
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            Vector<String> standards = new Vector<String>();
            Vector<Double> fees = new Vector<Double>();
            while (rs.next()) {
                standardCbo.addItem(rs.getString(1));
                feesCbo.addItem(String.valueOf(rs.getDouble(2)));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, e.getMessage());
            System.exit(0);
        }
    }

    private void loadData() {
        String SQL = "select name, standard from students";
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            data.removeAllElements();
            if (!fill) {
                //Get header names
                ResultSetMetaData rsmd = rs.getMetaData();
                col.add(rsmd.getColumnName(1));
                col.add(rsmd.getColumnName(2));
            }
            //get data
            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString(1));
                v.add(rs.getString(2));
                data.add(v);
            }
            TableModel model = new DefaultTableModel(data, col);
            mainTable.setModel(model);
            rs.close();
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, e);
        }
    }

    private boolean validates() {
        if (nameField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(parentField, "Name can not be empty!", "Alert", JOptionPane.ERROR_MESSAGE);
            nameField.requestFocus();
            return false;
        }
        String stuName = nameField.getText().trim();
        Iterator it = data.iterator();
        while (it.hasNext()) {
            Vector v = (Vector) it.next();
            String name = ((String) v.get(0)).trim();
            if (stuName.equalsIgnoreCase(name)) {
                JOptionPane.showMessageDialog(parentField, "The student has already existed!", "Alert", JOptionPane.ERROR_MESSAGE);
                nameField.grabFocus();
                return false;
            }
        }
        if (adrArea.getText().isEmpty()) {
            JOptionPane.showMessageDialog(parentField, "Address field can not be empty!", "Alert", JOptionPane.ERROR_MESSAGE);
            adrArea.requestFocus();
            return false;
        }
        if (parentField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(parentField, "Parent name can not be empty!", "Alert", JOptionPane.ERROR_MESSAGE);
            parentField.requestFocus();
            return false;
        }
        if (contactField.getText().matches("^\\d{9}$") == false) {
            JOptionPane.showMessageDialog(parentField, "Contact must has length 9 and can not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
            contactField.requestFocus();
            return false;
        }
        if (standardCbo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(parentField, standardCbo.getSelectedItem());

        }
        return true;
    }

    private boolean duplicate(String s) {
        if (addNew == false) {
            return false;
        }
        for (int i = 0; i < data.size(); i++) {
            Vector v = (Vector) data.get(i);
            if (s.equalsIgnoreCase((String) v.get(i))) {
                return true;
            }
        }
        return false;
    }

    private void clearForm() {
        nameField.setText("");
        adrArea.setText("");
        parentField.setText("");
        contactField.setText("");
        standardCbo.setSelectedIndex(0);
        feesCbo.setSelectedIndex(0);
        nameField.requestFocus();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nameField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        adrArea = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        parentField = new javax.swing.JTextField();
        contactField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        standardCbo = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        feesCbo = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        newBtn = new javax.swing.JButton();
        insertBtn = new javax.swing.JButton();
        editBtn = new javax.swing.JButton();
        updBtn = new javax.swing.JButton();
        nextBtn = new javax.swing.JButton();
        preBtn = new javax.swing.JButton();
        delBtn = new javax.swing.JButton();
        exitBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        mainTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainTableMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                mainTableMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(mainTable);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Name");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Address");

        adrArea.setColumns(20);
        adrArea.setRows(5);
        jScrollPane2.setViewportView(adrArea);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Parent name");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("Contact No");

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("Standard");

        standardCbo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "..." }));
        standardCbo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                standardCboActionPerformed(evt);
            }
        });

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Fees");

        feesCbo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "..." }));
        feesCbo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feesCboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(parentField, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(contactField, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(standardCbo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(feesCbo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(parentField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(contactField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(standardCbo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(feesCbo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel3.setLayout(new java.awt.GridLayout(2, 0, 15, 10));

        newBtn.setText("New");
        newBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBtnActionPerformed(evt);
            }
        });
        jPanel3.add(newBtn);

        insertBtn.setText("Insert");
        insertBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertBtnActionPerformed(evt);
            }
        });
        jPanel3.add(insertBtn);

        editBtn.setText("Edit");
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });
        jPanel3.add(editBtn);

        updBtn.setText("Update");
        updBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updBtnActionPerformed(evt);
            }
        });
        jPanel3.add(updBtn);

        nextBtn.setText("Next");
        nextBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextBtnActionPerformed(evt);
            }
        });
        jPanel3.add(nextBtn);

        preBtn.setText("Previous");
        preBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                preBtnActionPerformed(evt);
            }
        });
        jPanel3.add(preBtn);

        delBtn.setText("Delete");
        delBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delBtnActionPerformed(evt);
            }
        });
        jPanel3.add(delBtn);

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });
        jPanel3.add(exitBtn);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void standardCboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_standardCboActionPerformed
        feesCbo.setSelectedIndex(standardCbo.getSelectedIndex());
    }//GEN-LAST:event_standardCboActionPerformed

    private void feesCboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feesCboActionPerformed
        standardCbo.setSelectedIndex(feesCbo.getSelectedIndex());
    }//GEN-LAST:event_feesCboActionPerformed

    private void mainTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainTableMouseReleased
        if (mainTable.getCellEditor() != null) {
            mainTable.getCellEditor().cancelCellEditing();
        }
    }//GEN-LAST:event_mainTableMouseReleased

    private void mainTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainTableMouseClicked
        try {
            rs.beforeFirst();
            clearForm();
            int row = mainTable.getSelectedRow();
            String name = (String) mainTable.getValueAt(row, 0);
            while (rs.next()) {
                String str = rs.getString(2);
                if (str.equalsIgnoreCase(name)) {
                    nameField.setText(rs.getString(2));
                    adrArea.setText(rs.getString(3));
                    parentField.setText(rs.getString(4));
                    contactField.setText(rs.getString(5));
                    standardCbo.setSelectedItem(rs.getString(6));
                    break;
                }
            }

        } catch (Exception e) {
            nameField.setEnabled(false);
            adrArea.setEnabled(false);
            parentField.setEnabled(false);
            contactField.setEnabled(false);
            standardCbo.setEnabled(false);
            feesCbo.setEnabled(false);
        }
    }//GEN-LAST:event_mainTableMouseClicked

    private void updBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updBtnActionPerformed
        try {
            //update
            pstUpdate.setString(1, adrArea.getText().trim());
            pstUpdate.setString(2, parentField.getText().trim());
            pstUpdate.setString(3, contactField.getText().trim());
            pstUpdate.setString(4, (String) standardCbo.getSelectedItem());
            pstUpdate.setString(5, nameField.getText().trim());
            pstUpdate.executeUpdate();
            loadData();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, e);
        }
    }//GEN-LAST:event_updBtnActionPerformed

    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtnActionPerformed
        updBtn.setEnabled(true);
        editBtn.setEnabled(true);
        nameField.setEditable(true);
        adrArea.setEditable(true);
        parentField.setEnabled(true);
        contactField.setEnabled(true);
        standardCbo.setEnabled(true);
        feesCbo.setEditable(true);
    }//GEN-LAST:event_editBtnActionPerformed

    private void preBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_preBtnActionPerformed
        try {
            rs.previous();
            nextBtn.setEnabled(true);
            if (rs.isBeforeFirst()) {
                preBtn.setEnabled(false);
                nextBtn.setEnabled(true);
                JOptionPane.showMessageDialog(parentField, "You've reached the first record!");
            } else {
                nameField.setText(rs.getString(2));
                adrArea.setText(rs.getString(3));
                parentField.setText(rs.getString(4));
                contactField.setText(rs.getString(5));
                standardCbo.setSelectedItem(rs.getString(6));
                mainTable.setRowSelectionInterval(rs.getRow() - 1, rs.getRow() - 1);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, "Error occured!!");
        }
    }//GEN-LAST:event_preBtnActionPerformed

    private void nextBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextBtnActionPerformed
        try {
            rs.next();
            preBtn.setEnabled(true);
            if (rs.isAfterLast() || rs.isBeforeFirst()) {
                nextBtn.setEnabled(false);
                preBtn.setEnabled(true);
                JOptionPane.showMessageDialog(parentField, "You've reached the last record!");
            } else {
                nameField.setText(rs.getString(2));
                adrArea.setText(rs.getString(3));
                parentField.setText(rs.getString(4));
                contactField.setText(rs.getString(5));
                standardCbo.setSelectedItem(rs.getString(6));
                mainTable.setRowSelectionInterval(rs.getRow() - 1, rs.getRow() - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_nextBtnActionPerformed

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        fill = false;
        System.exit(0);
    }//GEN-LAST:event_exitBtnActionPerformed

    private void delBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delBtnActionPerformed
        try {
            int n = mainTable.getSelectedRow();
            if (n >= 0) {
                Vector v = (Vector) data.get(n);
                int ans = JOptionPane.showConfirmDialog(parentField, "Do you really want to delete student "
                        + ((String) v.get(0)).trim(), "Confirmation", JOptionPane.YES_NO_OPTION);
                if (ans == JOptionPane.YES_OPTION) {
                    pstDelete.setString(1, (String) v.get(0));
                    pstDelete.executeUpdate();
                    loadData();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, e);
        }
    }//GEN-LAST:event_delBtnActionPerformed

    private void insertBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertBtnActionPerformed
        if (!validates()) {
            return;
        }
        String name = nameField.getText();
        String adr = adrArea.getText();
        String parent = parentField.getText();
        String phone = contactField.getText();
        String standard = (String) standardCbo.getSelectedItem();
        try {
            pstInsert.setString(1, name);
            pstInsert.setString(2, adr);
            pstInsert.setString(3, parent);
            pstInsert.setString(4, phone);
            pstInsert.setString(5, standard);
            int addRows = pstInsert.executeUpdate();
            loadData();
            clearForm();
            if (addRows > 0) {
                JOptionPane.showMessageDialog(parentField, "Student details have been saved!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parentField, "Failed to save data in database!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_insertBtnActionPerformed

    private void newBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBtnActionPerformed
        clearForm();
    }//GEN-LAST:event_newBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(bai2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(bai2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(bai2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(bai2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize LaF");
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new bai2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea adrArea;
    private javax.swing.JTextField contactField;
    private javax.swing.JButton delBtn;
    private javax.swing.JButton editBtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JComboBox<String> feesCbo;
    private javax.swing.JButton insertBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable mainTable;
    private javax.swing.JTextField nameField;
    private javax.swing.JButton newBtn;
    private javax.swing.JButton nextBtn;
    private javax.swing.JTextField parentField;
    private javax.swing.JButton preBtn;
    private javax.swing.JComboBox<String> standardCbo;
    private javax.swing.JButton updBtn;
    // End of variables declaration//GEN-END:variables
}
