﻿create database LAB6_SCHOOL
use LAB6_LIBRARY
go

create table standards(
	standard nvarchar(50) primary key,
	fees float null
)

create table students(
	id int identity primary key,
	name nvarchar(50) null,
	address nvarchar(50) null,
	parentname nvarchar(50) null,
	phone nvarchar(50) null,
	standard nvarchar(50) foreign key references standards(standard),
	regdate datetime null
)

INSERT INTO [dbo].[standards] ([standard], [fees]) VALUES ('A0','92000')
INSERT INTO [dbo].[standards] ([standard], [fees]) VALUES ('A1','45000')
INSERT INTO [dbo].[standards] ([standard], [fees]) VALUES ('B0','32000')
INSERT INTO [dbo].[standards] ([standard], [fees]) VALUES ('B1','22000')
INSERT INTO [dbo].[standards] ([standard], [fees]) VALUES ('C0','20000')
INSERT INTO [dbo].[standards] ([standard], [fees]) VALUES ('C1','12000')

INSERT [dbo].[students] ([name], [address], [parentname], [phone], [standard], [regdate]) VALUES (N'Nguyễn Tuấn Kỳ', N'34/3/2 Hải Ninh', N'Tuấn Hải', N'038275938', N'A1', CAST(N'2017-07-23T00:00:00.000' AS DateTime))
INSERT [dbo].[students] ([name], [address], [parentname], [phone], [standard], [regdate]) VALUES (N'Trần Tuấn Tào', N'21/3/5 Đinh Long', N'Trần Ninh Lao', N'038574869', N'A0', CAST(N'2019-03-02T00:00:00.000' AS DateTime))
INSERT [dbo].[students] ([name], [address], [parentname], [phone], [standard], [regdate]) VALUES (N'Lê Thị Linh Lẩu', N'12/3/5 Âu Cơ', N'Lê Công Bò', N'012938443', N'B1', CAST(N'2016-03-18T00:00:00.000' AS DateTime))
INSERT [dbo].[students] ([name], [address], [parentname], [phone], [standard], [regdate]) VALUES (N'Hồ Tuấn Mì', N'04/23/2 Phú Linh', N'Lê Trần Gói', N'093837283', N'C1', CAST(N'2020-02-18T00:00:00.000' AS DateTime))


select * from standards
select name, standard from students

