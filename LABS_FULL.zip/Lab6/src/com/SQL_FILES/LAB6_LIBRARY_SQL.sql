﻿create database LAB6_LIBRARY
use LAB6_LIBRARY
go

create table BOOKs(
	id int identity primary key,
	title nvarchar(50) null,
	price float null
)

insert into BOOKS(title, price) values(N'Lập trình Java',57000)
insert into BOOKS(title, price) values(N'Lập trình C++',40000)
insert into BOOKS(title, price) values(N'Lập trình C#',35000)
insert into BOOKS(title, price) values(N'Lập trình Swift',98000)
insert into BOOKS(title, price) values(N'Lập trình Go',38000)
insert into BOOKS(title, price) values(N'Lập trình Cobol',53000)
insert into BOOKS(title, price) values(N'Lập trình C',19000)

