/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.phan1;

import java.io.*;
import java.net.*;

/**
 *
 * @author balis
 */
public class Bai1_Server {

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8888);
            System.out.println("Server is connecting...");
            Socket socket = serverSocket.accept();
            System.out.println("Server is connect...");
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            while (true) {
                double num1 = dis.readDouble();
                double num2 = dis.readDouble();
                System.out.println("2 numbers received from Client is: " + num1 + ", " + num2);
                double sum = num1 + num2;
                dos.writeDouble(sum);
                dos.flush();
                System.out.println("Sum of 2 numbers is: " + sum);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
