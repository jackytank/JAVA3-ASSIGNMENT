/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.phan1;

import java.io.*;
import java.util.*;
import java.net.Socket;

/**
 *
 * @author balis
 */
public class Bai1_Client {

    public static void main(String[] args) {
        try {
            System.out.println("Client is connecting...");
            Socket socket = new Socket("localhost", 8888);
            System.out.println("Client is connect");
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            while (true) {
                System.out.println("Enter first number: ");
                dos.writeDouble(new Scanner(System.in).nextDouble());
                dos.flush();
                System.out.println("Enter second number: ");
                dos.writeDouble(new Scanner(System.in).nextDouble());
                dos.flush();
                System.out.println("Sum of 2 number is: " + dis.readDouble());
                System.out.println("Continue? (Y/N)");
                String ans = new Scanner(System.in).nextLine();
                if (ans.equalsIgnoreCase("n")) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
