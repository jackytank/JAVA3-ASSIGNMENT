/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.phan2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import javax.swing.JTextPane;

/**
 *
 * @author balis
 */
public class ChatServer {

    private Socket socket;
    private JTextPane textPane;
    private PrintWriter out;
    private BufferedReader in;

    public ChatServer(Socket socket, JTextPane textPane) throws IOException {
        this.socket = socket;
        this.textPane = textPane;

        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        receive();
    }

    private void receive() {
        Thread t = new Thread() {
            public void run() {
                while (true) {
                    try {
                        String line = in.readLine();
                        if (line != null) {
                            textPane.setText(textPane.getText() + "\n" + line);
                        }
                    } catch (Exception e) {
                    }
                }
            }

        };
        t.start();
    }

    public void send(String meg) {
        String current = textPane.getText();
        textPane.setText(current + "\nSent: " + meg);
        out.println(meg);
        out.flush();
    }

    public void close() {
        try {
            out.close();
            in.close();
            socket.close();
        } catch (Exception e) {
        }
    }

}
