/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.phan1;

import java.sql.*;

/**
 *
 * @author balis
 */
public class Bai1 {

    private static String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=LAB5_QLSV;";
    private static String USER_NAME = "sa";
    private static String PASSWORD = "1221";

    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
            Statement stmt = conn.createStatement();
            String SQL = "select * from STUDENTS";
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                System.out.print(rs.getString("id") + ", ");
                System.out.print(rs.getString("fname") + ", ");
                System.out.print(rs.getString("email") + ", ");
                System.out.print(rs.getString("phone") + ", ");
                System.out.print(rs.getString("gender") + ", ");
                System.out.println(rs.getString("address"));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
