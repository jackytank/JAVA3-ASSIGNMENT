/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Entity;

/**
 *
 * @author balis
 */
public class GRADE {

    private String id;
    private String name;
    private int en;
    private int it;
    private int pe;
    private float avg;

    public GRADE() {
    }

    public GRADE(String id, String name, int en, int it, int pe, float avg) {
        this.id = id;
        this.name = name;
        this.en = en;
        this.it = it;
        this.pe = pe;
        this.avg = avg;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEn() {
        return en;
    }

    public void setEn(int en) {
        this.en = en;
    }

    public int getIt() {
        return it;
    }

    public void setIt(int it) {
        this.it = it;
    }

    public int getPe() {
        return pe;
    }

    public void setPe(int pe) {
        this.pe = pe;
    }

    public float getAvg() {
        return avg;
    }

    public void setAvg(float avg) {
        this.avg = avg;
    }

}
