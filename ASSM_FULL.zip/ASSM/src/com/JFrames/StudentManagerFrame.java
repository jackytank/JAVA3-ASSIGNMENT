/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template photoFile, choose Tools | Templates
 * and open the template in the editor.
 */
package com.JFrames;

import com.DAO.DAO;
import com.Entity.STUDENTS;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author balis
 */
public class StudentManagerFrame extends javax.swing.JFrame implements DAO<STUDENTS> {

    List<STUDENTS> studentList = new ArrayList<>();
    TimeClock timeClock = new TimeClock();
    JButton lastPressed = null;
    Connection conn = null;
    ResultSet rs;
    PreparedStatement pstDetails = null;
    PreparedStatement pstInsert = null;
    PreparedStatement pstUpdate = null;
    PreparedStatement pstDelete = null;
    String sqlInsert = "INSERT INTO STUDENTS VALUES (?,?,?,?,?,?,?)";
    String sqlUpdate = "UPDATE STUDENTS SET name = ?, email = ?, phone = ?, gender = ?, address = ?, photo = ? WHERE student_id = ?";
    String sqlDelete = "DELETE FROM STUDENTS WHERE student_id = ?";
    String USERNAME = "sa";
    String PASSWORD = "1221";
    String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=ASSM_JAVA3;";
    String demoPhotoPath = "com/Resources/StudentPhoto/";
    String photoName = "";
    String error = "";
    String emailRegex = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$";
    File photoFile = null;
    //create a storage folder to store all student photos saved by user
    File photoFolder = new File(System.getProperty("user.dir") + "\\photoFolder");
    int pos = -1;

    /**
     * Creates new form qlsvFrame
     */
    public StudentManagerFrame() {
        initComponents();
        setTitle("Student Management Application");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        timeClock.start();
        //create folder if not exist
        photoFolder.mkdirs();
        loadDBToArray();
        fillTable();
    }

    private void loadDBToArray() {
        try {
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM STUDENTS");
            studentList.clear();
            rs.isBeforeFirst();
            while (rs.next()) {
                String id = rs.getString(1);
                String name = rs.getString(2);
                String email = rs.getString(3);
                String phone = rs.getString(4);
                boolean gender = rs.getBoolean(5);
                String address = rs.getString(6);
                String photo = rs.getString(7);
                studentList.add(new STUDENTS(id, name, email, phone, gender, address, photo));
            }
            conn.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fillTable() {
        DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
        model.setRowCount(0);
        for (STUDENTS e : studentList) {
            model.addRow(new Object[]{e.getStudent_id(), e.getName(), e.getEmail(), e.getPhone(),
                e.getGender() ? "Male" : "Female", e.getAddress(), e.getPhoto()});
        }
    }

    private void setDisplay(STUDENTS e) {
        idField.setText(e.getStudent_id());
        nameField.setText(e.getName());
        emailField.setText(e.getEmail());
        phoneField.setText(e.getPhone());
        maleRadio.setSelected(e.getGender());
        femaleRadio.setSelected(!e.getGender());
        adrArea.setText(e.getAddress());
        //display photo from storage folder
        photoLabel.setIcon(getScaledImage(FileUtils.getFile(photoFolder, e.getPhoto()).getAbsolutePath(), photoLabel));
    }

    private ImageIcon getScaledImage(String path, JLabel label) {
        ImageIcon ii = new ImageIcon(path);
        Image image = ii.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon newII = new ImageIcon(image);
        return newII;
    }

    private boolean isFormValidated() {
        boolean isValid = true;
        error = "";
        if (isDuplicated() == true) {
            error += "Student ID is duplicated!\n";
            idField.requestFocus();
            isValid = false;
        }
        if (idField.getText().isEmpty()) {
            error += "Student ID mustn't empty!\n";
            idField.requestFocus();
            isValid = false;
        }
        if (nameField.getText().isEmpty()) {
            error += "Name mustn't empty!\n";
            isValid = false;
        }
        if (emailField.getText().matches(emailRegex) == false) {
            error += "Email is not valid!\n";
            isValid = false;
        }
        if (phoneField.getText().length() != 9) {
            error += "Phone number must have length of 9!\n";
            isValid = false;
        }
        if (genderGroup.getSelection() == null) {
            error += "Gender must be chosen!\n";
            isValid = false;
        }
        if (adrArea.getText().isEmpty()) {
            error += "Address mustn't empty!\n";
            isValid = false;
        }
        return isValid;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        genderGroup = new javax.swing.ButtonGroup();
        mainPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        photoLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        idField = new javax.swing.JTextField();
        nameField = new javax.swing.JTextField();
        emailField = new javax.swing.JTextField();
        phoneField = new javax.swing.JTextField();
        maleRadio = new javax.swing.JRadioButton();
        femaleRadio = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        adrArea = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        newButton = new javax.swing.JButton();
        saveButton = new javax.swing.JButton();
        updButton = new javax.swing.JButton();
        delButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        firstButton2 = new javax.swing.JButton();
        preButton = new javax.swing.JButton();
        nextButton = new javax.swing.JButton();
        lastButton = new javax.swing.JButton();
        browseButton = new javax.swing.JButton();
        signinButton = new javax.swing.JButton();
        findField = new javax.swing.JTextField();
        timeLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainPanelMouseClicked(evt);
            }
        });
        mainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("STUDENT MANAGEMENT APPLICATION");
        mainPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 480, 30));

        photoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        photoLabel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Photo", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(204, 204, 204))); // NOI18N
        mainPanel.add(photoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 210, 210));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("ID");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 9, 60, -1));

        jLabel4.setText("Name");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 37, 60, -1));

        jLabel5.setText("Email");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 65, 60, -1));

        jLabel6.setText("Phone");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 93, 60, -1));

        jLabel7.setText("Gender");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 118, 60, -1));

        jLabel8.setText("Address");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 140, 60, -1));

        idField.setEnabled(false);
        jPanel2.add(idField, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 6, 200, -1));

        nameField.setEnabled(false);
        jPanel2.add(nameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 34, 200, -1));

        emailField.setEnabled(false);
        jPanel2.add(emailField, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 62, 200, -1));

        phoneField.setEnabled(false);
        phoneField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                phoneFieldKeyReleased(evt);
            }
        });
        jPanel2.add(phoneField, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 90, 200, -1));

        genderGroup.add(maleRadio);
        maleRadio.setText("Male");
        maleRadio.setEnabled(false);
        jPanel2.add(maleRadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 118, 74, 16));

        genderGroup.add(femaleRadio);
        femaleRadio.setText("Female");
        femaleRadio.setEnabled(false);
        jPanel2.add(femaleRadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(158, 118, 110, 16));

        adrArea.setColumns(20);
        adrArea.setRows(5);
        adrArea.setEnabled(false);
        jScrollPane1.setViewportView(adrArea);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 140, 200, 60));

        mainPanel.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 290, 200));

        jPanel4.setLayout(new java.awt.GridLayout(4, 1, 0, 10));

        newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_add_user_male_20px.png"))); // NOI18N
        newButton.setText("  New");
        newButton.setActionCommand("New");
        newButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        newButton.setContentAreaFilled(false);
        newButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        newButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newButtonActionPerformed(evt);
            }
        });
        jPanel4.add(newButton);

        saveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_save_all_20px.png"))); // NOI18N
        saveButton.setText("  Save");
        saveButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        saveButton.setContentAreaFilled(false);
        saveButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });
        jPanel4.add(saveButton);

        updButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_update_user_20px.png"))); // NOI18N
        updButton.setText("Update");
        updButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        updButton.setContentAreaFilled(false);
        updButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        updButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updButtonActionPerformed(evt);
            }
        });
        jPanel4.add(updButton);

        delButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_delete_20px.png"))); // NOI18N
        delButton.setText("Delete");
        delButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        delButton.setContentAreaFilled(false);
        delButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        delButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delButtonActionPerformed(evt);
            }
        });
        jPanel4.add(delButton);

        mainPanel.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 100, 150, 140));

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "STUDENT_ID", "NAME", "EMAIL", "PHONE", "GENDER", "ADDRESS", "PHOTO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        studentTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        studentTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        studentTable.setShowGrid(true);
        studentTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                studentTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(studentTable);

        mainPanel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 850, 300));

        firstButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_double_left_20px.png"))); // NOI18N
        firstButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstButton2ActionPerformed(evt);
            }
        });
        jPanel5.add(firstButton2);

        preButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_left_20px.png"))); // NOI18N
        preButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                preButtonActionPerformed(evt);
            }
        });
        jPanel5.add(preButton);

        nextButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_right_20px.png"))); // NOI18N
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        jPanel5.add(nextButton);

        lastButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_double_right_20px.png"))); // NOI18N
        lastButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastButtonActionPerformed(evt);
            }
        });
        jPanel5.add(lastButton);

        mainPanel.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 650, 180, -1));

        browseButton.setText("Browse");
        browseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                browseButtonActionPerformed(evt);
            }
        });
        mainPanel.add(browseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, -1, -1));

        signinButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Resources/Icon/icons8_back_20px.png"))); // NOI18N
        signinButton.setText("Sign in");
        signinButton.setBorderPainted(false);
        signinButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signinButtonActionPerformed(evt);
            }
        });
        mainPanel.add(signinButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        findField.setBackground(new java.awt.Color(242, 242, 242));
        findField.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search ID", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));
        findField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                findFieldKeyReleased(evt);
            }
        });
        mainPanel.add(findField, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 280, 150, 40));

        timeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        timeLabel.setForeground(new java.awt.Color(255, 0, 0));
        mainPanel.add(timeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 650, 160, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 852, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void studentTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_studentTableMouseClicked
        pos = studentTable.getSelectedRow();
        setDisplay(studentList.get(pos));
        setFieldsEditable(false, false);
    }//GEN-LAST:event_studentTableMouseClicked

    private void newButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newButtonActionPerformed
        lastPressed = newButton;
        clearForm();
        setFieldsEditable(true, false);
    }//GEN-LAST:event_newButtonActionPerformed
    private void clearForm() {
        //set empty
        idField.setText("");
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        genderGroup.clearSelection();
        adrArea.setText("");
        photoLabel.setIcon(null);
        studentTable.clearSelection();
    }
    private void updButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updButtonActionPerformed
        lastPressed = updButton;
        setFieldsEditable(true, true);
    }//GEN-LAST:event_updButtonActionPerformed

    private void mainPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseClicked
        studentTable.clearSelection();
        setFieldsEditable(false, false);
        pos = -1;
    }//GEN-LAST:event_mainPanelMouseClicked

    private void delButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delButtonActionPerformed
        if (pos == -1) {
            JOptionPane.showMessageDialog(rootPane, "Select a student to delete!");
        } else if (studentTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(rootPane, "The table is empty!");
        } else {
            int tmp = JOptionPane.showConfirmDialog(rootPane, "Do you want to delete student " + studentList.get(pos).getStudent_id(),
                    "Confirmation", JOptionPane.YES_NO_OPTION);
            if (tmp == JOptionPane.YES_OPTION) {
                deleteStudent();
                clearForm();
            }
        }
        pos = -1;
        studentTable.clearSelection();
    }//GEN-LAST:event_delButtonActionPerformed
    @Override
    public void deleteStudent() {
        try {
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            pstDelete = conn.prepareStatement(sqlDelete);
            pstDelete.setString(1, idField.getText());
            pstDelete.executeUpdate();
            conn.close();
            pstDelete.close();
            loadDBToArray();
            fillTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        if (lastPressed == newButton) {
            insertStudent();
        } else if (lastPressed == updButton) {
            updateStudent();
        }
    }//GEN-LAST:event_saveButtonActionPerformed

    @Override
    public void insertStudent() {
        if (isFormValidated() == false) {
            JOptionPane.showMessageDialog(rootPane, error);
            return;
        }
        try {
            //start inserting
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            pstInsert = conn.prepareStatement(sqlInsert);
            pstInsert.setString(1, idField.getText().toUpperCase());
            pstInsert.setString(2, nameField.getText());
            pstInsert.setString(3, emailField.getText());
            pstInsert.setString(4, phoneField.getText());
            pstInsert.setBoolean(5, maleRadio.isSelected());
            pstInsert.setString(6, adrArea.getText());
            pstInsert.setString(7, photoName);
            pstInsert.executeUpdate();
            conn.close();
            pstInsert.close();
            loadDBToArray();
            fillTable();
            setFieldsEditable(false, false);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateStudent() {
        try {
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            pstUpdate = conn.prepareStatement(sqlUpdate);
            pstUpdate.setString(1, nameField.getText());
            pstUpdate.setString(2, emailField.getText());
            pstUpdate.setString(3, phoneField.getText());
            pstUpdate.setBoolean(4, maleRadio.isSelected());
            pstUpdate.setString(5, adrArea.getText());
            pstUpdate.setString(6, photoName);
            pstUpdate.setString(7, idField.getText());
            pstUpdate.executeUpdate();
            conn.close();
            pstUpdate.close();
            loadDBToArray();
            fillTable();
            setFieldsEditable(false, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isDuplicated() {
        for (STUDENTS e : studentList) {
            if (e.getStudent_id().equalsIgnoreCase(idField.getText())) {
                return true;
            }
        }
        return false;
    }

    private void firstButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstButton2ActionPerformed
        pos = 0;
        if (!studentList.isEmpty()) {
            setDisplay(studentList.get(pos));
            studentTable.setRowSelectionInterval(pos, pos);
        }
    }//GEN-LAST:event_firstButton2ActionPerformed

    private void preButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_preButtonActionPerformed
        pos--;
        if (pos < 0) {
            pos = 0;
        }
        if (!studentList.isEmpty()) {
            setDisplay(studentList.get(pos));
            studentTable.setRowSelectionInterval(pos, pos);
        }
    }//GEN-LAST:event_preButtonActionPerformed

    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        pos++;
        if (pos > studentList.size() - 1) {
            pos = studentList.size() - 1;
        }
        if (!studentList.isEmpty()) {
            setDisplay(studentList.get(pos));
            studentTable.setRowSelectionInterval(pos, pos);
        }
    }//GEN-LAST:event_nextButtonActionPerformed

    private void lastButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastButtonActionPerformed
        pos = studentList.size() - 1;
        if (!studentList.isEmpty()) {
            setDisplay(studentList.get(pos));
            studentTable.setRowSelectionInterval(pos, pos);
        }
    }//GEN-LAST:event_lastButtonActionPerformed

    private void browseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_browseButtonActionPerformed
        try {
            JFileChooser chooser = new JFileChooser(new File(".").getCanonicalPath() + "\\src\\com\\Resources\\StudentPhoto");
            chooser.setDialogTitle("Choose Photo");
            //set filter
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            FileNameExtensionFilter filter = new FileNameExtensionFilter("IMAGES", "png", "jpg", "jpeg");
            chooser.setFileFilter(filter);
            int returnValue = chooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                photoFile = chooser.getSelectedFile();
                photoName = photoFile.getName();
                //copy selected file to storage folder
                if (lastPressed == newButton || lastPressed == updButton) {
                    FileUtils.copyFileToDirectory(photoFile, photoFolder);
                }
                //display the copied file to GUI
                photoLabel.setIcon(getScaledImage(FileUtils.getFile(photoFolder, photoName).getAbsolutePath(), photoLabel));
            }
        } catch (IOException ex) {
            Logger.getLogger(StudentManagerFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_browseButtonActionPerformed

    private void signinButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signinButtonActionPerformed
        new SigninFrame().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_signinButtonActionPerformed

    private void phoneFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneFieldKeyReleased
        char c = evt.getKeyChar();
        if (Character.isLetter(c)) {
            phoneField.setText("");
            phoneField.requestFocus();
        }
    }//GEN-LAST:event_phoneFieldKeyReleased

    private void findFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_findFieldKeyReleased
        if (findField.getText().isEmpty()) {
            loadDBToArray();
            fillTable();
        } else {
            find();
        }
    }//GEN-LAST:event_findFieldKeyReleased
    private void find() {
        try {
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM STUDENTS WHERE student_id like ?");
            stmt.setString(1, "%" + findField.getText() + "%");
            rs = stmt.executeQuery();
            studentList.clear();
            while (rs.next()) {
                String id = rs.getString(1);
                String name = rs.getString(2);
                String email = rs.getString(3);
                String phone = rs.getString(4);
                boolean gender = rs.getBoolean(5);
                String address = rs.getString(6);
                String photo = rs.getString(7);
                studentList.add(new STUDENTS(id, name, email, phone, gender, address, photo));
            }
            fillTable();
            conn.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setFieldsEditable(boolean fieldsState, boolean exceptID) {
        //Ex: if fieldsState is 'true' and exceptID is 'true' then all field will be enabled except for ID,..v..v
        Enumeration<AbstractButton> enumeration = genderGroup.getElements();
        while (enumeration.hasMoreElements()) {
            enumeration.nextElement().setEnabled(fieldsState);
        }
        if (exceptID == true) {
            idField.setEnabled(!fieldsState);
        } else {
            idField.setEnabled(fieldsState);
        }
        nameField.setEnabled(fieldsState);
        emailField.setEnabled(fieldsState);
        phoneField.setEnabled(fieldsState);
        adrArea.setEnabled(fieldsState);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StudentManagerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StudentManagerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StudentManagerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StudentManagerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize LaF");
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudentManagerFrame().setVisible(true);
            }
        });
    }

    class TimeClock extends Thread {

        @Override
        public void run() {
            while (true) {
                timeLabel.setText(new SimpleDateFormat("hh:mm:ss a").format(Calendar.getInstance().getTime()));
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea adrArea;
    private javax.swing.JButton browseButton;
    private javax.swing.JButton delButton;
    private javax.swing.JTextField emailField;
    private javax.swing.JRadioButton femaleRadio;
    private javax.swing.JTextField findField;
    private javax.swing.JButton firstButton2;
    private javax.swing.ButtonGroup genderGroup;
    private javax.swing.JTextField idField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton lastButton;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JRadioButton maleRadio;
    private javax.swing.JTextField nameField;
    private javax.swing.JButton newButton;
    private javax.swing.JButton nextButton;
    private javax.swing.JTextField phoneField;
    private javax.swing.JLabel photoLabel;
    private javax.swing.JButton preButton;
    private javax.swing.JButton saveButton;
    private javax.swing.JButton signinButton;
    private javax.swing.JTable studentTable;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JButton updButton;
    // End of variables declaration//GEN-END:variables
}
