-- JAVA3_PS15506_TOMINHTRI_ASSM

CREATE DATABASE ASSM_JAVA3
USE ASSM_JAVA3

-- CREATE TABLES
CREATE TABLE STUDENTS(
	student_id nvarchar(50) primary key,
	name nvarchar(50) null,
	email nvarchar(50) null,
	phone nvarchar(15) null,
	gender bit null,
	address nvarchar(50) null,
	photo nvarchar(50) null
)

CREATE TABLE GRADE(
	id int identity primary key,
	student_id nvarchar(50) foreign key references STUDENTS(student_id) on delete cascade on update cascade,
	en int null,
	it int null,
	pe int null
)

CREATE TABLE USERS(
	username nvarchar(50) primary key,
	password nvarchar(50) null,
	role nvarchar(50) null
)
go

-- INSERT BASE DATA
INSERT INTO USERS VALUES(N'admin',N'1234',N'Manager')
INSERT INTO USERS VALUES(N'monica',N'1234',N'Teacher')

INSERT INTO STUDENTS VALUES(N'PS01',N'Ava Johndottir',N'ava@gmail.com','0395849589','0',N'56/3/2 St. Boulevard',N'ava.jpg')
INSERT INTO STUDENTS VALUES(N'PS02',N'Dennis Garcia',N'dennis@yahoo.com','079485938','1',N'23/5 Hilton',N'dennis.jpg')
INSERT INTO STUDENTS VALUES(N'PS03',N'Emma Miller',N'emma@gmail.com','028334968','0',N'19/2 St. Camac',N'emma.jpg')
INSERT INTO STUDENTS VALUES(N'PS04',N'Hela Anderdottir',N'hela@gmail.com','029938377','0',N'12/3 Indian Queen',N'hela.jpg')
INSERT INTO STUDENTS VALUES(N'PS05',N'Jessica Rambeau',N'jessica@yahoo.com','012936483','0',N'1/2 St. McCain',N'jessica.jpg')
INSERT INTO STUDENTS VALUES(N'PS06',N'Wang Cheng',N'wang@gmail.com','029465938','1',N'23/3 St.Unruh',N'wang.jpg')

INSERT INTO GRADE (student_id,en,it,pe) VALUES(N'PS01','6','4','3')
INSERT INTO GRADE (student_id,en,it,pe) VALUES(N'PS02','5','9','9')
INSERT INTO GRADE (student_id,en,it,pe) VALUES(N'PS03','8','4','8')
INSERT INTO GRADE (student_id,en,it,pe) VALUES(N'PS04','5','9','10')
INSERT INTO GRADE (student_id,en,it,pe) VALUES(N'PS05','1','9','7')
INSERT INTO GRADE (student_id,en,it,pe) VALUES(N'PS06','9','6','8')


select top 3 stu.student_id, stu.name,en, it, pe,convert(decimal(10,1),(en+it+pe)/3.0) as average 
from GRADE gra inner join STUDENTS stu on stu.student_id = gra.student_id order by average desc




